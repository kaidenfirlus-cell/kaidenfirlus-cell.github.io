# Kaiden's Catalog of Work

This is my collection of assignments, projects, and course material for Math and Philosophy.
Built with HTML, CSS, JS and hosted using GitHub Pages.
